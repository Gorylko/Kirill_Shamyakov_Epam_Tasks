﻿namespace Task1.DataInitializers.Params
{
    public class TaxCalculatorParams
    {
        public int CompanyCount { get; set; }

        public double Profit { get; set; }

        public double TaxPercentage { get; set; }
    }
}
