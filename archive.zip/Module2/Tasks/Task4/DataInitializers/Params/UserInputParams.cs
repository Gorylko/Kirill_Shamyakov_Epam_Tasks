﻿using Task4.Enums;

namespace Task4.DataInitializers.Params
{
    public class UserInputParams
    {
        public ShapeType ShapeType { get; set; }

        public ParamType ParamType { get; set; }
    }
}
