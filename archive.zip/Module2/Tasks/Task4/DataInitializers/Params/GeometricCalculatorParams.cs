﻿namespace Task4.DataInitializers.Params
{
    public class GeometricCalculatorParams
    {
        public double GeneralArea { get; set; }

        public double Perimeter { get; set; }
    }
}
