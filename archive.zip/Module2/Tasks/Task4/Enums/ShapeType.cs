﻿namespace Task4.Enums
{
    public enum ShapeType
    {
        Circle   = 1,
        Square   = 2,
        Triangle = 3
    }
}