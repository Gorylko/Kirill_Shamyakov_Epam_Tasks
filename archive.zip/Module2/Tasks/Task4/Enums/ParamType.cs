﻿namespace Task4.Enums
{
    public enum ParamType
    {
        Area = 1,
        Perimeter = 2
    }
}
